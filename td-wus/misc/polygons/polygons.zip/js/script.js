/**
 * Treehouse FSJS Techdegree - Code Adventure
 * Polygons - JS
 * Developed by: Robert Manolis - Student Success Specialist
 *               Milwaukie, OR - 2019
 */

"use strict";

const squareCount = sideLength => {
  
  // variable to store the result of the code you write
  // after you craft your logic below, set the value of this variable to equal your results
  let result = 0;

  // helpful log statement to display polygon side length and result variable
  console.log(`For a polygon with a side length of ${sideLength}, your result is ${result}`);

  // YOUR CODE GOES HERE!!! 
  
  // determine and return the total number of squares in a polygon based on the number of squares that make up one side



  return result;
}