/**
 * Treehouse FSJS Techdegree - Code Adventure
 * What's on the other side - JS
 * Developed by: Robert Manolis - Student Success Specialist
 *               Milwaukie, OR - 2019
 */

"use strict";


const findTheOtherSide = (tp, sp) => {

  // YOUR CODE GOES HERE!!!

  // Remember, the tp parameter equals the total number of points on a given circle
  // and the sp parameter equals a specific point on the circle 

  // Your job is to return the number directly opposite the sp parameter

  // Here's a helpful log statement to print to the console the value of the parameters
  // for the four tests being used to check your code
  // Feel free to change the log statement or delete it if you like

  console.log(`Total points = ${tp}.  Specific point = ${sp}.`);
  
}